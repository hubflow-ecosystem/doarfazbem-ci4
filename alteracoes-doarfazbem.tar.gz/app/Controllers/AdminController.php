<?php

namespace App\Controllers;

use App\Models\CampaignModel;
use App\Models\DonationModel;
use App\Models\UserModel;

class AdminController extends BaseController
{
    protected $campaignModel;
    protected $donationModel;
    protected $userModel;

    public function __construct()
    {
        $this->campaignModel = new CampaignModel();
        $this->donationModel = new DonationModel();
        $this->userModel = new UserModel();
    }

    /**
     * Verificar se usuário é admin
     */
    private function checkAdmin()
    {
        if (!session()->get('isLoggedIn')) {
            return redirect()->to('/login');
        }

        // TODO: Adicionar verificação de role admin
        // Por enquanto, qualquer usuário logado pode acessar
        // Você deve adicionar um campo 'role' na tabela users
        /*
        if (session()->get('role') !== 'admin') {
            return redirect()->to('/dashboard')->with('error', 'Acesso negado');
        }
        */

        return null;
    }

    /**
     * Super Admin Dashboard
     */
    public function dashboard()
    {
        $check = $this->checkAdmin();
        if ($check) return $check;

        // Dados para KPI Cards
        $currentMonth = date('Y-m');
        $previousMonth = date('Y-m', strtotime('-1 month'));

        $platformTotal = $this->getPlatformTotal();
        $prevPlatformTotal = $this->getPlatformTotal($previousMonth);

        $activeUsers = $this->userModel->countAll();
        $prevActiveUsers = $this->userModel
            ->where('DATE_FORMAT(created_at, "%Y-%m") <=', $previousMonth)
            ->countAllResults();

        $totalCampaigns = $this->campaignModel->countAll();
        $prevTotalCampaigns = $this->campaignModel
            ->where('DATE_FORMAT(created_at, "%Y-%m") <=', $previousMonth)
            ->countAllResults();

        // Taxa de sucesso (campanhas que atingiram meta)
        $successRate = $this->getSuccessRate();
        $prevSuccessRate = $this->getSuccessRate($previousMonth);

        // Dados para Gráfico de Crescimento (10 meses)
        $growthLabels = [];
        $growthData = [];

        for ($i = 9; $i >= 0; $i--) {
            $month = date('Y-m', strtotime("-$i months"));
            $monthLabel = $this->getMonthName(date('m', strtotime("-$i months")));

            $growthLabels[] = $monthLabel;
            $growthData[] = $this->getPlatformTotal($month);
        }

        // Campanhas Recentes para Tabela
        $recentCampaigns = $this->getRecentCampaignsForAdmin(20);

        $data = [
            'title' => 'Super Admin Dashboard',

            // KPI Cards
            'platform_total' => $platformTotal,
            'prev_platform_total' => $prevPlatformTotal,
            'active_users' => $activeUsers,
            'prev_active_users' => $prevActiveUsers,
            'total_campaigns' => $totalCampaigns,
            'prev_total_campaigns' => $prevTotalCampaigns,
            'success_rate' => $successRate,
            'prev_success_rate' => $prevSuccessRate,

            // Growth Chart
            'growth_labels' => $growthLabels,
            'growth_data' => $growthData,

            // Recent Campaigns Table
            'recent_campaigns' => $recentCampaigns
        ];

        return view('admin/dashboard', $data);
    }

    /**
     * Gerenciar Campanhas
     */
    public function campaigns()
    {
        $check = $this->checkAdmin();
        if ($check) return $check;

        $campaigns = $this->campaignModel
            ->select('campaigns.*, users.name as creator_name, users.email as creator_email')
            ->join('users', 'users.id = campaigns.user_id')
            ->orderBy('campaigns.created_at', 'DESC')
            ->findAll();

        // Adicionar estatísticas
        foreach ($campaigns as &$campaign) {
            $campaign['donors_count'] = $this->getDonorsCount($campaign['id']);
            $campaign['raised_amount'] = $this->getCampaignRaised($campaign['id']);
            $campaign['percentage'] = ($campaign['raised_amount'] / max(1, $campaign['goal_amount'])) * 100;
        }

        $data = [
            'title' => 'Gerenciar Campanhas',
            'campaigns' => $campaigns
        ];

        return view('admin/campaigns', $data);
    }

    /**
     * Gerenciar Usuários
     */
    public function users()
    {
        $check = $this->checkAdmin();
        if ($check) return $check;

        $users = $this->userModel->findAll();

        // Adicionar estatísticas de cada usuário
        foreach ($users as &$user) {
            $user['campaigns_count'] = $this->campaignModel->where('user_id', $user['id'])->countAllResults();
            $user['total_raised'] = $this->getUserTotalRaised($user['id']);
        }

        $data = [
            'title' => 'Gerenciar Usuários',
            'users' => $users
        ];

        return view('admin/users', $data);
    }

    /**
     * Gerenciar Doações
     */
    public function donations()
    {
        $check = $this->checkAdmin();
        if ($check) return $check;

        $donations = $this->donationModel
            ->select('donations.*, campaigns.title as campaign_title, campaigns.slug as campaign_slug, users.name as creator_name')
            ->join('campaigns', 'campaigns.id = donations.campaign_id')
            ->join('users', 'users.id = campaigns.user_id')
            ->orderBy('donations.created_at', 'DESC')
            ->findAll();

        $data = [
            'title' => 'Gerenciar Doações',
            'donations' => $donations,
            'total_donated' => array_sum(array_column($donations, 'amount'))
        ];

        return view('admin/donations', $data);
    }

    /**
     * Relatórios
     */
    public function reports()
    {
        $check = $this->checkAdmin();
        if ($check) return $check;

        // Estatísticas Gerais
        $stats = [
            'total_users' => $this->userModel->countAll(),
            'total_campaigns' => $this->campaignModel->countAll(),
            'active_campaigns' => $this->campaignModel->where('status', 'active')->countAllResults(),
            'completed_campaigns' => $this->campaignModel->where('status', 'completed')->countAllResults(),
            'total_donations' => $this->donationModel->where('status', 'received')->countAllResults(),
            'total_raised' => $this->getPlatformTotal(),
            'average_donation' => $this->getAverageDonation(),

            // Por Categoria
            'medica_total' => $this->getTotalByCategory('medica'),
            'social_total' => $this->getTotalByCategory('social'),
            'educacao_total' => $this->getTotalByCategory('educacao'),
            'negocio_total' => $this->getTotalByCategory('negocio'),
            'criativa_total' => $this->getTotalByCategory('criativa'),

            // Por Método de Pagamento
            'pix_total' => $this->getTotalByPaymentMethod('pix'),
            'credit_card_total' => $this->getTotalByPaymentMethod('credit_card'),
            'boleto_total' => $this->getTotalByPaymentMethod('boleto'),

            // Crescimento
            'new_users_month' => $this->getNewUsersThisMonth(),
            'new_campaigns_month' => $this->getNewCampaignsThisMonth(),
            'donations_month' => $this->getDonationsThisMonth()
        ];

        $data = [
            'title' => 'Relatórios',
            'stats' => $stats
        ];

        return view('admin/reports', $data);
    }

    // ========================================
    // MÉTODOS AUXILIARES
    // ========================================

    private function getPlatformTotal($month = null)
    {
        $builder = $this->donationModel
            ->select('SUM(amount) as total')
            ->where('status', 'received');

        if ($month) {
            $builder->where('DATE_FORMAT(created_at, "%Y-%m")', $month);
        }

        $result = $builder->get()->getRowArray();
        return $result['total'] ?? 0;
    }

    private function getSuccessRate($month = null)
    {
        $builder = $this->campaignModel->select('
            COUNT(*) as total,
            SUM(CASE WHEN (
                SELECT SUM(amount)
                FROM donations
                WHERE donations.campaign_id = campaigns.id
                AND donations.status = "received"
            ) >= campaigns.goal_amount THEN 1 ELSE 0 END) as successful
        ');

        if ($month) {
            $builder->where('DATE_FORMAT(created_at, "%Y-%m") <=', $month);
        }

        $result = $builder->get()->getRowArray();

        if (!$result || $result['total'] == 0) {
            return 0;
        }

        return ($result['successful'] / $result['total']) * 100;
    }

    private function getRecentCampaignsForAdmin($limit = 20)
    {
        $campaigns = $this->campaignModel
            ->select('campaigns.*, users.name as creator')
            ->join('users', 'users.id = campaigns.user_id')
            ->orderBy('campaigns.created_at', 'DESC')
            ->limit($limit)
            ->findAll();

        // Formatar para JSON
        $formatted = [];
        foreach ($campaigns as $campaign) {
            $raised = $this->getCampaignRaised($campaign['id']);

            $formatted[] = [
                'id' => $campaign['id'],
                'title' => $campaign['title'],
                'creator' => $campaign['creator'],
                'category' => ucfirst($campaign['category']),
                'raised' => (float) $raised,
                'goal' => (float) $campaign['goal_amount'],
                'status' => $this->translateStatus($campaign['status'])
            ];
        }

        return $formatted;
    }

    private function getDonorsCount($campaignId)
    {
        return $this->donationModel
            ->where('campaign_id', $campaignId)
            ->where('status', 'received')
            ->countAllResults();
    }

    private function getCampaignRaised($campaignId)
    {
        $result = $this->donationModel
            ->select('SUM(amount) as total')
            ->where('campaign_id', $campaignId)
            ->where('status', 'received')
            ->get()
            ->getRowArray();

        return $result['total'] ?? 0;
    }

    private function getUserTotalRaised($userId)
    {
        $result = $this->donationModel
            ->select('SUM(donations.amount) as total')
            ->join('campaigns', 'campaigns.id = donations.campaign_id')
            ->where('campaigns.user_id', $userId)
            ->where('donations.status', 'received')
            ->get()
            ->getRowArray();

        return $result['total'] ?? 0;
    }

    private function getTotalByCategory($category)
    {
        $result = $this->donationModel
            ->select('SUM(donations.amount) as total')
            ->join('campaigns', 'campaigns.id = donations.campaign_id')
            ->where('campaigns.category', $category)
            ->where('donations.status', 'received')
            ->get()
            ->getRowArray();

        return $result['total'] ?? 0;
    }

    private function getTotalByPaymentMethod($method)
    {
        $result = $this->donationModel
            ->select('SUM(amount) as total')
            ->where('payment_method', $method)
            ->where('status', 'received')
            ->get()
            ->getRowArray();

        return $result['total'] ?? 0;
    }

    private function getAverageDonation()
    {
        $result = $this->donationModel
            ->select('AVG(amount) as average')
            ->where('status', 'received')
            ->get()
            ->getRowArray();

        return $result['average'] ?? 0;
    }

    private function getNewUsersThisMonth()
    {
        $currentMonth = date('Y-m');
        return $this->userModel
            ->where('DATE_FORMAT(created_at, "%Y-%m")', $currentMonth)
            ->countAllResults();
    }

    private function getNewCampaignsThisMonth()
    {
        $currentMonth = date('Y-m');
        return $this->campaignModel
            ->where('DATE_FORMAT(created_at, "%Y-%m")', $currentMonth)
            ->countAllResults();
    }

    private function getDonationsThisMonth()
    {
        $currentMonth = date('Y-m');
        $result = $this->donationModel
            ->select('SUM(amount) as total')
            ->where('DATE_FORMAT(created_at, "%Y-%m")', $currentMonth)
            ->where('status', 'received')
            ->get()
            ->getRowArray();

        return $result['total'] ?? 0;
    }

    private function translateStatus($status)
    {
        $map = [
            'active' => 'Ativa',
            'completed' => 'Concluída',
            'paused' => 'Pausada',
            'cancelled' => 'Cancelada'
        ];

        return $map[$status] ?? ucfirst($status);
    }

    private function getMonthName($month)
    {
        $months = [
            '01' => 'Jan', '02' => 'Fev', '03' => 'Mar', '04' => 'Abr',
            '05' => 'Mai', '06' => 'Jun', '07' => 'Jul', '08' => 'Ago',
            '09' => 'Set', '10' => 'Out', '11' => 'Nov', '12' => 'Dez'
        ];

        return $months[$month] ?? '';
    }
}
